# 安装

```
pip install with_timeout
```

# 使用示例

```python
from with_timeout import with_timeout
@with_timeout(5)
def my_func():
    pass
```

